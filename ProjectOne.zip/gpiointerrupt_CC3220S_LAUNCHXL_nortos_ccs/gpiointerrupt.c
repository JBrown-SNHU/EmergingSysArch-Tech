/*
 * Copyright (c) 2015-2020, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== gpiointerrupt.c ========
 */
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <string.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>

/* Driver configuration */
#include "ti_drivers_config.h"


/*
 * Task Struct
 */
typedef struct task {
    int state; // current state of the task
    unsigned long period; // Rate at which the task should tick
    unsigned long elapsedTime; // Time since task's previous tick
    int (*TickFct)(int); //Function to call for task's tick
} task;


// Constant Variables
const unsigned char tasksNum = 3;
const unsigned long tasksPeriodGCD = 100000;
const unsigned long periodCheckButtons = 200000;
const unsigned long periodCheckTemp = 500000;
const unsigned long periodUpdateLED = 1000000;
task tasks[3];


// Flags
volatile unsigned char ButtonFlag0 = 0; // Assigned to button 0
volatile unsigned char ButtonFlag1 = 0; // Assigned to button 1
volatile unsigned char SecondFlag = 0;  // Used to print to UART every second

// Global Variables
unsigned char setpoint = 21;    // Set the manual temperature
unsigned char heat = 0;         // Represents the heater 0 off 1 is on
int16_t temperature;            // The current temperature of the room
unsigned long seconds = 0;      // The seconds since board is reset


int16_t readTemp(void);


// State Machine to Check Temperature
enum TP_States {TP_SMStart, TP_Mid, TP_Hi, TP_Low} TP_State;
int TickFct_CheckTemp(int state);

int TickFct_CheckTemp(int state) {
    switch(TP_State) {
    // Starting State
    case TP_SMStart:
        TP_State = TP_Mid;
        break;

    /*
     * Mid State: If temperature is equal to setpoint then it will stay in Mid state
     * If lower than setpoint it will go to High State
     * I higher than setpoint it will go to Low State.
     */
    case TP_Mid:

        if (temperature == setpoint) {
            TP_State = TP_Mid;
        }
        else if (temperature > setpoint) {
            TP_State = TP_Hi;
        }
        else if (temperature < setpoint) {
            TP_State = TP_Low;
        }
        break;

   /*
    * If the temp is lower than setpoint, it will remain in High State
    * If lower or equal to setpoint, then it will go back to Mid State
    */
    case TP_Hi:
        if (temperature > setpoint) {
            TP_State = TP_Hi;
        }
        else if (temperature <= setpoint) {
            TP_State = TP_Mid;
        }
        break;

    /*
     * If temp is greater than setpoint, it will remain in Low State
     * If higher or equal to setpoint, then it will go back to Mid State
     */
    case TP_Low:
        if (temperature < setpoint) {
            TP_State = TP_Low;
        }
        else if (temperature >= setpoint) {
            TP_State = TP_Mid;
        }
        break;

    default:
        TP_State = TP_SMStart;
        break;
    }

    /*
     * If in High State the Heater will be set to off
     * If in Low State the heater will be set to on.
     */
    switch(TP_State) {
    case TP_Mid:
        break;
    case TP_Hi:
        heat = 0;
        break;
    case TP_Low:
        heat = 1;
        break;
    default:
        break;
    }
    return state;
}

// State Machine to Check Buttons
enum BT_States {BT_SMStart, BT_Neutral, BT_0, BT_1} BT_State;
int TickFct_CheckButtons(int state);

int TickFct_CheckButtons(int state) {
    switch(BT_State) {
    case BT_SMStart:
        BT_State = BT_Neutral;
        break;

    /*
     * If Neither button is pressed, it will remain in Neutral State
     * If a button is pressed, it will go to the corresponding state
     */
    case BT_Neutral:
        if (!ButtonFlag0 && !ButtonFlag1) {
            BT_State = BT_Neutral;
        }
        else if(ButtonFlag0) {
            BT_State = BT_0;
        }
        else if(ButtonFlag1) {
            BT_State = BT_1;
        }
        break;

    /*
     * If the flag has yet to be reset, then it will remain in state,
     * if reset it will go back to neutral state
     */
    case BT_0:
        if (ButtonFlag0) {
            BT_State = BT_0;
        }
        else {
            BT_State = BT_Neutral;
        }
        break;


     /*
      * If the flag has yet to be reset, then it will remain in state,
      * if reset it will go back to neutral state
      */
    case BT_1:
        if (ButtonFlag1) {
            BT_State = BT_1;
        }
        else {
            BT_State = BT_Neutral;
        }
        break;

    default:
        BT_State = BT_SMStart;
        break;
    }

    /*
     * Button 0, lowers the setpoint
     * Button 1, raises the setpoint
     */
    switch(BT_State) {
    case BT_Neutral:
        break;
    case BT_0:
        --setpoint;
        ButtonFlag0 = 0;
        break;
    case BT_1:
        ++setpoint;
        ButtonFlag1 = 0;
        break;
    default:
        break;
    }
    return state;
}

// State Machine to Update LED
enum LT_States {LT_SMStart, LT_LEDOn, LT_LEDOff} LT_State;
int TickFctUpdatLED(int state);

/*
 * If the heat is on, it will switch to LED ON State
 * If the heat is off, it will switch to LED OFF State
 */
int TickFct_UpdateLED(int state) {
    switch(LT_State) {
    case LT_SMStart:
        LT_State = LT_LEDOff;
        break;

    case LT_LEDOn:
        if (heat == 1) {
            LT_State = LT_LEDOn;
        }
        else if (heat == 0) {
            LT_State = LT_LEDOff;
        }
        break;

    case LT_LEDOff:
        if (heat == 0) {
            LT_State = LT_LEDOff;
        }
        else if (heat == 1) {
            LT_State = LT_LEDOn;
        }
        break;

    default:
        LT_State = LT_SMStart;
        heat = 0;
        break;
    }

    switch(LT_State) {
    case LT_LEDOn:
        GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
        break;

    case LT_LEDOff:
        GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
        break;

    default:
        break;
    }
    return state;
}


/*
 *  ======== gpioButtonFxn0 ========
 *  Callback function for the GPIO interrupt on CONFIG_GPIO_BUTTON_0.
 *
 *  Note: GPIO interrupts are cleared prior to invoking callbacks.
 */
void gpioButtonFxn0(uint_least8_t index)
{
    ButtonFlag0 = 1;
}

/*
 *  ======== gpioButtonFxn1 ========
 *  Callback function for the GPIO interrupt on CONFIG_GPIO_BUTTON_1.
 *  This may not be used for all boards.
 *
 *  Note: GPIO interrupts are cleared prior to invoking callbacks.
 */
void gpioButtonFxn1(uint_least8_t index)
{
    ButtonFlag1 = 1;
}


/*
 * UART Driver
 */
#include <ti/drivers/UART.h>

#define DISPLAY(x) UART_write(uart, &output, x);

// UART Global Variables
char output[64];
int bytesToSend;

// Driver Handles - Global variables
UART_Handle uart;

void initUART(void)
{
    UART_Params uartParams;
    // Init the driver
    UART_init();
    // Configure the driver
    UART_Params_init(&uartParams);
    uartParams.writeDataMode = UART_DATA_BINARY;
    uartParams.readDataMode = UART_DATA_BINARY;
    uartParams.readReturnMode = UART_RETURN_FULL;
    uartParams.baudRate = 115200;
    // Open the driver
    uart = UART_open(CONFIG_UART_0, &uartParams);
    if (uart == NULL) {
        /* UART_open() failed */
        while (1);
    }
}

/*
 * I2C Driver
 */
#include <ti/drivers/I2C.h>

// I2C Global Variables
static const struct {
    uint8_t address;
    uint8_t resultReg;
    char *id;
}
sensors[3] = {
              { 0x48, 0x0000, "11X" },
              { 0x49, 0x0000, "116" },
              { 0x41, 0x0001, "006" }
};
uint8_t txBuffer[1];
uint8_t rxBuffer[2];
I2C_Transaction i2cTransaction;

// Driver Handles - Global variables
I2C_Handle i2c;

// Make sure you call initUART() before calling this function.
void initI2C(void)
{
    int8_t i, found;
    I2C_Params i2cParams;
    DISPLAY(snprintf(output, 64, "Initializing I2C Driver - "));
    // Init the driver
    I2C_init();
    // Configure the driver
    I2C_Params_init(&i2cParams);
    i2cParams.bitRate = I2C_400kHz;
    // Open the driver
    i2c = I2C_open(CONFIG_I2C_0, &i2cParams);
    if (i2c == NULL)
    {
        DISPLAY(snprintf(output, 64, "Failed\n\r"));
        while (1);
    }

    DISPLAY(snprintf(output, 32, "Passed\n\r"));
    // Boards were shipped with different sensors.
    // Welcome to the world of embedded systems.
    // Try to determine which sensor we have.
    // Scan through the possible sensor addresses
    /* Common I2C transaction setup */
    i2cTransaction.writeBuf = txBuffer;
    i2cTransaction.writeCount = 1;
    i2cTransaction.readBuf = rxBuffer;
    i2cTransaction.readCount = 0;
    found = false;
    for (i=0; i<3; ++i)
    {
        i2cTransaction.slaveAddress = sensors[i].address;
        txBuffer[0] = sensors[i].resultReg;
        DISPLAY(snprintf(output, 64, "Is this %s? ", sensors[i].id));
        if (I2C_transfer(i2c, &i2cTransaction))
        {
            DISPLAY(snprintf(output, 64, "Found\n\r"));
            found = true;
            break;
        }
        DISPLAY(snprintf(output, 64, "No\n\r"));
    }

    if(found)
    {
        DISPLAY(snprintf(output, 64, "Detected TMP%s I2C address: %x\n\r",
                         sensors[i].id, i2cTransaction.slaveAddress));
    }
    else
    {
        DISPLAY(snprintf(output, 64, "Temperature sensor not found, contact professor\n\r"));
    }
}

int16_t readTemp(void)
{
    int16_t temperature = 0;
    i2cTransaction.readCount = 2;
    if (I2C_transfer(i2c, &i2cTransaction))
    {
        /*
         * Extract degrees C from the received data;
         * see TMP sensor datasheet
         */
        temperature = (rxBuffer[0] << 8) | (rxBuffer[1]);
        temperature *= 0.0078125;
        /*
         * If the MSB is set '1', then we have a 2's complement
         * negative value which needs to be sign extended
         */
        if (rxBuffer[0] & 0x80)
        {
            temperature |= 0xF000;
        }
    }
    else
    {
        DISPLAY(snprintf(output, 64,
                         "Error reading temperature sensor(%d)\n\r",i2cTransaction.status));
        DISPLAY(snprintf(output, 64, "Please power cycle your board by unplugging USB and plugging back in.\n\r"));
    }

    return temperature;
}


/*
 * Timer Driver
 */
#include <ti/drivers/Timer.h>

// Driver Handles - Global variables
Timer_Handle timer0;


volatile unsigned char TimerFlag = 0;
void timerCallback(Timer_Handle myHandle, int_fast16_t status)
{
    TimerFlag = 1;

    unsigned char i;
    for (i = 0; i < tasksNum; ++i) {
        /*
         * Used to increase the seconds timer for the board and set the second flag
         */
        if (tasks[i].elapsedTime >= periodUpdateLED) {
            ++seconds;
            SecondFlag = 1;
        }
        if (tasks[i].elapsedTime >= tasks[i].period) {
            tasks[i].state = tasks[i].TickFct(tasks[i].state);
            tasks[i].elapsedTime = 0;
        }
        tasks[i].elapsedTime += tasksPeriodGCD;
    }
}

void initTimer(void)
{
    Timer_Params params;
    // Init the driver
    Timer_init();
    // Configure the driver
    Timer_Params_init(&params);
    params.period = tasksPeriodGCD;
    params.periodUnits = Timer_PERIOD_US;
    params.timerMode = Timer_CONTINUOUS_CALLBACK;
    params.timerCallback = timerCallback;

    // Open the driver
    timer0 = Timer_open(CONFIG_TIMER_0, &params);
    if (timer0 == NULL) {
        /* Failed to initialized timer */
        while (1) {
            printf("Failed to initialize timer");
        }
    }
    if (Timer_start(timer0) == Timer_STATUS_ERROR) {
        /* Failed to start timer */
        while (1) {
            printf("Failed to start timer");
        }
    }
}


/*
 *  ======== mainThread ========
 */
void *mainThread(void *arg0)
{
    /* Call driver init functions */
    GPIO_init();

    /* Configure the LED and button pins */
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_BUTTON_0, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

    /* Turn on user LED */
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);

    /* Install Button callback */
    GPIO_setCallback(CONFIG_GPIO_BUTTON_0, gpioButtonFxn0);

    /* Enable interrupts */
    GPIO_enableInt(CONFIG_GPIO_BUTTON_0);

    /*
     *  If more than one input pin is available for your device, interrupts
     *  will be enabled on CONFIG_GPIO_BUTTON1.
     */
    if (CONFIG_GPIO_BUTTON_0 != CONFIG_GPIO_BUTTON_1) {
        /* Configure BUTTON1 pin */
        GPIO_setConfig(CONFIG_GPIO_BUTTON_1, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

        /* Install Button callback */
        GPIO_setCallback(CONFIG_GPIO_BUTTON_1, gpioButtonFxn1);
        GPIO_enableInt(CONFIG_GPIO_BUTTON_1);
    }

    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);

    initUART();
    initI2C();
    initTimer();

    unsigned char i = 0;

    // Update LED Task: updates the LED every second
    tasks[i].state = LT_SMStart;
    tasks[i].period = periodUpdateLED;
    tasks[i].elapsedTime = tasks[i].period;
    tasks[i].TickFct = &TickFct_UpdateLED;
    ++i;

    // Check Buttons Task: checks the button every 200ms
    tasks[i].state = BT_SMStart;
    tasks[i].period = periodCheckButtons;
    tasks[i].elapsedTime = tasks[i].period;
    tasks[i].TickFct = &TickFct_CheckButtons;
    ++i;

    // Check Temperature Task: Checks the temperature every 500ms
    tasks[i].state = TP_SMStart;
    tasks[i].period = periodCheckTemp;
    tasks[i].elapsedTime = tasks[i].period;
    tasks[i].TickFct = &TickFct_CheckTemp;

    // Loop Forever
    // The student should add flags (similar to the timer flag) to the button handlers.
    while (1)
    {
        // Reads the temperature of the room
        temperature = readTemp();

        while (!TimerFlag) {}   // Wait for timer period
        TimerFlag = 0;          // Lower flag raised by timer
        /*
         * Used to determine if a second has passed.
         * Outputs to the UART every second
         * Lowers the second flag to do so again.
         */
        if (SecondFlag == 1) {
            DISPLAY( snprintf(output, 64, "<%02d,%02d,%d,%04d>\n\r", temperature, setpoint, heat, seconds));
            SecondFlag = 0;
        }
    }

}
